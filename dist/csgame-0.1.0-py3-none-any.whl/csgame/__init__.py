import pygame

import csgame.menu
import csgame.colour
import csgame.player
import csgame.camera